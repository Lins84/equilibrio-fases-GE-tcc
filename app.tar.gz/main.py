import flet as ft
from interface.fletando_grafico import main

ft.run(main)
