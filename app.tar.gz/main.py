﻿import sys
sys.path.insert(0, "interface")
import flet as ft
import fletando_grafico
ft.run(fletando_grafico.main)
